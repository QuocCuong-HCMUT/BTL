amax=40; vmax=40;
t1 = vmax/amax;
%Link1
global q0theta1 q3theta1 qtheta1 t3theta1 ttheta1 vtheta1  atheta1
t3theta1=(2*((q0theta1+q3theta1)/2-(amax*t1/2+q0theta1-vmax*t1))/vmax);
ttheta1 = 0:0.1:t3theta1;
lengthTtheta1 = length(ttheta1);
qtheta1 =zeros(lengthTtheta1, 1);
vtheta1 = zeros(lengthTtheta1, 1);
atheta1 = zeros(lengthTtheta1, 1);
for i = 1:1:lengthTtheta1
    if ttheta1(i) <= t1
        qtheta1(i) = (amax / 2) * ttheta1(i)^2 + q0theta1;
        vtheta1(i) = amax * ttheta1(i);
        atheta1(i) = amax;
    elseif ttheta1(i) <= t3theta1 - t1 && ttheta1(i) > t1
        qtheta1(i) = vmax * ttheta1(i) + (amax / 2) * t1^2 + q0theta1 - vmax * t1;
        vtheta1(i) = vmax;
        atheta1(i) = 0;
    elseif ttheta1(i) > t3theta1 - t1 && ttheta1(i) <= t3theta1
        qtheta1(i) = (-amax / 2) * ttheta1(i)^2 + amax * t3theta1 * ttheta1(i) +(q3theta1-(amax/2)*t3theta1^2);
        vtheta1(i) = -amax * ttheta1(i) + amax * t3theta1;
        atheta1(i) = -amax;
    end
end

%Link2
global q0theta2 q3theta2 qtheta2 vtheta2 ttheta2  atheta2 t3theta2
t3theta2=(2*((q0theta2+q3theta2)/2-(amax*t1/2+q0theta2-vmax*t1))/vmax);
ttheta2 = 0:0.1:t3theta2;
lengthTtheta2 = length(ttheta2);
qtheta2 =zeros(lengthTtheta2, 1);
vtheta2 = zeros(lengthTtheta2, 1);
atheta2 = zeros(lengthTtheta2, 1);
for i = 1:1:lengthTtheta2
    if ttheta2(i) <= t1
        qtheta2(i) = (amax / 2) * ttheta2(i)^2 + q0theta2;
        vtheta2(i) = amax * ttheta2(i);
        atheta2(i) = amax;
    elseif ttheta2(i) <= t3theta2 - t1 && ttheta2(i) > t1
        qtheta2(i) = vmax * ttheta2(i) + (amax / 2) * t1^2 + q0theta2 - vmax * t1;
        vtheta2(i) = vmax;
        atheta2(i) = 0;
    elseif ttheta2(i) > t3theta2 - t1 &&ttheta2(i) <= t3theta2
        qtheta2(i) = (-amax / 2) *ttheta2(i)^2 + amax * t3theta2 *ttheta2(i) +(q3theta2-(amax/2)*t3theta2^2);
        vtheta2(i) = -amax * ttheta2(i) + amax * t3theta2;
        atheta2(i) = -amax;
    end
end

%Link3
global q0theta3 q3theta3 qtheta3 vtheta3 ttheta3  atheta3 t3theta3
t3theta3=(2*((q0theta3+q3theta3)/2-(amax*t1/2+q0theta3-vmax*t1))/vmax);
ttheta3 = 0:0.1:t3theta3;
lengthTtheta3 = length(ttheta3);
qtheta3 =zeros(lengthTtheta3, 1);
vtheta3 = zeros(lengthTtheta3, 1);
atheta3 = zeros(lengthTtheta3, 1);
for i = 1:1:lengthTtheta3
    if ttheta3(i) <= t1
        qtheta3(i) = (amax / 2) * ttheta3(i)^2 + q0theta3;
        vtheta3(i) = amax * ttheta3(i);
        atheta3(i) = amax;
    elseif ttheta3(i) <= t3theta3 - t1 && ttheta3(i) > t1
        qtheta3(i) = vmax * ttheta3(i) + (amax / 2) * t1^2 + q0theta3 - vmax * t1;
        vtheta3(i) = vmax;
        atheta3(i) = 0;
    elseif ttheta3(i) > t3theta3 - t1 &&ttheta3(i) <= t3theta3
        qtheta3(i) = (-amax / 2) *ttheta3(i)^2 + amax * t3theta3 *ttheta3(i) +(q3theta3-(amax/2)*t3theta3^2);
        vtheta3(i) = -amax * ttheta3(i) + amax * t3theta3;
        atheta3(i) = -amax;
    end
end
plot(ttheta3,atheta3);
grid on;

