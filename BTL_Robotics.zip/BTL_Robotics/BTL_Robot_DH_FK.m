% Ve Articulated Arm Robot bang MATLAB
global theta1 theta2 theta3 PX PY PZ
cla %Xoa trang thai truoc
% Thiet lap goc theta
hold on;
grid on;
axis equal;
% Tao h�nh tru cho khop
[X,Y,Z] = cylinder(2); %Ban kinh truc base 
h = 10; %d(O0,O1)
Z = Z * h;
surf(X, Y, Z); % Tao hinh tru truc base

% tao gia tri bang DH
a1 = 0; alpha1 = pi/2; d1 = h; 
a2 = 12; alpha2 = 0; d2 = 0; 
a3 = 10; alpha3 = 0; d3 = 0; 
% T�nh c�c ma tran bien doi thuan nhat
A01=[cosd(theta1) 0 sind(theta1)  0;
     sind(theta1) 0 -cosd(theta1) 0;
          0       1       0       d1; 
          0       0       0       1];
A12 = [cosd(theta2) -sin(theta2) 0 a2*cosd(theta2);
       sind(theta2) cosd(theta2) 0 a2*sind(theta2);
           0              0      1             0;
           0              0      0             1];
A23 = [cosd(theta3) -sind(theta3) 0  a3*cosd(theta3);
       sind(theta3) cosd(theta3)  0  a3*sind(theta3);
            0           0         1         0;
            0           0         0         1];

% T�nh c�c ma tran bien doi 
T01=A01;
T02=A01*A12;
T03=A01*A12*A23;


% Ve c�c khop va lien ket
% Link 1
% tinh tien tu O0 -> O1 (Ma tran P)
x_link1 = [0 T01(1,4)];
y_link1 = [0 T01(2,4)];
z_link1 = [0 T01(3,4)];
plot3(x_link1, y_link1, z_link1, 'LineWidth', 15, 'Color', [1 0 1 0.7]);
scatter3(T01(1,4), T01(2,4), T01(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.5, 'MarkerEdgeAlpha', 0.5);

% Link 2
x_link2 = [T01(1,4) T02(1,4)];
y_link2 = [T01(2,4) T02(2,4)];
z_link2 = [T01(3,4) T02(3,4)];
plot3(x_link2, y_link2, z_link2, 'LineWidth', 10, 'Color', [0 1 0 0.7]);
scatter3(T02(1,4), T02(2,4), T02(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.5, 'MarkerEdgeAlpha', 0.5);

% Link 3
x_link3 = [T02(1,4) T03(1,4)];
y_link3 = [T02(2,4) T03(2,4)];
z_link3 = [T02(3,4) T03(3,4)];
plot3(x_link3, y_link3, z_link3, 'LineWidth', 10, 'Color', [1 1 0 0.7]);
scatter3(T03(1,4), T03(2,4), T03(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.7, 'MarkerEdgeAlpha', 0.7);

% Thiet lap view v� labels, hien thi he truc 3 chieu
view(3);
xlabel('Truc X'); ylabel('Truc Y'); zlabel('Truc Z');
title('Articulated Arm');
axis([-40 40 -40 40 -40 40]);

% Hien thi ma tran bien doi
disp('A01 = ');
disp(A01);
disp('A12 = ');
disp(A12);
disp('A23 = ');
disp(A23);

T = T03;
disp('Ma tran bien doi T01 = ');
disp(T01);
disp('Ma tran bien doi T02 = ');
disp(T02);
disp('Ma tran bien doi T03 = ');
disp(T03);
%T�nh ma tr?n Jacobian
z0 = [0; 0; 1];
z1 = T01(1:3, 3);
z2 = T02(1:3, 3);
p0 = [0; 0; 0];
p1 = T01(1:3, 4);
p2 = T02(1:3, 4);
p3 = T03(1:3, 4);
disp('z1 = ');
disp(z1);
disp('z2 = ');
disp(z2);
disp('p1 = ');
disp(p1);
disp('p2 = ');
disp(p2);
disp('p3 = ');
disp(p3);
u0 = p3-p0;
u1 = p3-p1;
u2 = p3-p2;
J0 = [-z0(3,1)*u0(2,1)+z0(2,1)*u0(3,1); 
       z0(3,1)*u0(1,1)-z0(1,1)*u0(3,1);
       -z0(2,1)*u0(1,1)+z0(1,1)*u0(2,1)];
J1 =[-z1(3,1)*u1(2,1)+z1(2,1)*u1(3,1); 
       z1(3,1)*u1(1,1)-z1(1,1)*u1(3,1);
       -z1(2,1)*u1(1,1)+z1(1,1)*u1(2,1)]; 
J2 =[-z2(3,1)*u2(2,1)+z2(2,1)*u2(3,1); 
       z2(3,1)*u2(1,1)-z2(1,1)*u2(3,1);
       -z2(2,1)*u2(1,1)+z2(1,1)*u2(2,1)];
disp('J0 = ');
disp(J0);
disp('J1 = ');
disp(J1);
disp('J2 = ');
disp(J2);
J = [J0, J1, J2;
    z0, z1, z2];
disp('J= ');
disp(J);
% T�m ?i?m k� d? det_Ja = 0
Ja = [J0, J1, J2];
det_Ja = det(Ja);
disp('det_Ja=');
disp(det_Ja);