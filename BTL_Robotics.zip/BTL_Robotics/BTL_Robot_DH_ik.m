% Tinh toan dong hoc nghich
% Ve Articulated Arm Robot bang MATLAB
global PX PY PZ theta1 theta2 theta3
cla %Xoa trang thai truoc
% Thiet lap goc theta
hold on;
grid on;
axis equal;
% Tao h�nh tru cho khop
[X,Y,Z] = cylinder(2); %Ban kinh truc base 
h = 10; %d(O0,O1)
Z = Z * h;
surf(X, Y, Z); % Tao hinh tru truc base

% tao gia tri bang DH
a1 = 0; alpha1 = pi/2; d1 = h; 
a2 = 12; alpha2 = 0; d2 = 0; 
a3 = 10; alpha3 = 0; d3 = 0;
% ??nh ngh?a c�c th�ng s?
Wx = PX; 
Wy = PY;
Wz = PZ;
distance = sqrt(Wx^2 + Wy^2 + Wz^2);
if (abs(a2 - a3) <= distance) && (distance <= a2 + a3)
%Tinh goc theta1 
th1 = rad2deg(atan2(PY,PX));
%Tinh goc theta3
r =sqrt( PX^2 + PY^2 + PZ^2);
c3 = (r^2 - a2^2 - a3^2)/(2*a2*a3);
s3 = sqrt((1 - c3^2));
th3 =rad2deg(atan2(s3, c3));
%Tinh goc theta2
c2 = (sqrt(PY^2+PZ^2)*(a2 + a3*c3)+PZ*a3*s3)/(a2^2+a3^2*a2*a3*c3);
s2 = (sqrt(PY^2+PZ^2)*(a3*s3)+PZ*(a2 + a3*c3))/(a2^2+a3^2*a2*a3*c3);
th2 =rad2deg(atan2(s2, c2));
 % Hi?n th? k?t qu?
disp('Theta1 = ');
disp(th1);
disp('Theta2 = ');
disp(th2);
disp('Theta3 = ');
disp(th3);
theta1=th1;
theta2=th2;
theta3=th3;
else
    error('ngo�i ph?m vi l�m vi?c c?a robot!');
end
% T�nh c�c ma tr?n bi?n ??i thu?n nh?t
a01=[cosd(th1) 0 sind(th1)  0;
     sind(th1) 0 -cosd(th1) 0;
          0       1       0       d1; 
          0       0       0       1];
a12 = [cosd(th2) -sin(th2) 0 a2*cosd(th2);
       sind(th2) cosd(th2) 0 a2*sind(th2);
           0              0      1             0;
           0              0      0             1];
a23 = [cosd(th3) -sind(th3) 0  a3*cosd(th3);
       sind(th3) cosd(th3)  0  a3*sind(th3);
            0           0         1         0;
            0           0         0         1];
t01=a01;
t02=a01*a12;
t03=a01*a12*a23;
%Hi?n th? ma tr?n
t = t03;
disp('Ma tran bien doi t03 = ');
disp(t03);
% V? c�c kh?p v� li�n k?t cho ??ng h?c ngh?ch
% Link 1
X_link1 = [0 t01(1,4)];
Y_link1 = [0 t01(2,4)];
Z_link1 = [0 t01(3,4)];
plot3(X_link1, Y_link1, Z_link1, 'LineWidth', 15, 'Color', [1 0 1 0.7]);
%Ve point khop
scatter3(t01(1,4), t01(2,4), t01(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.5, 'MarkerEdgeAlpha', 0.5);
% Link 2
X_link2 = [t01(1,4) t02(1,4)];
Y_link2 = [t01(2,4) t02(2,4)];
Z_link2 = [t01(3,4) t02(3,4)];
plot3(X_link2, Y_link2, Z_link2, 'LineWidth', 10, 'Color', [0 1 0 0.7]);
scatter3(t02(1,4), t02(2,4), t02(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.5, 'MarkerEdgeAlpha', 0.5);
% Link 3
X_link3 = [t02(1,4) t03(1,4)];
Y_link3 = [t02(2,4) t03(2,4)];
Z_link3 = [t02(3,4) t03(3,4)];
plot3(X_link3, Y_link3, Z_link3, 'LineWidth', 10, 'Color', [1 1 0 0.7]);
scatter3(t03(1,4), t03(2,4), t03(3,4), 80, 'm', 'filled', 'MarkerEdgeColor', 'm', 'MarkerFaceAlpha', 0.7, 'MarkerEdgeAlpha', 0.7);
% Thiet lap view v� labels, hien thi he truc 3 chieu
view(3);
xlabel('Truc X'); ylabel('Truc Y'); zlabel('Truc Z');
title('Articulated Arm');
axis([-40 40 -40 40 -40 40]);